//HT UI Assessment by Gabriel Sawich
//I hereby state that all below code is original work belonging to me

//Wait until pageload to execute
window.addEventListener('load', mainFunction, false);

function mainFunction() {
    //Create input field and execution button
    var mainDiv = document.createElement("DIV");
    var watchDiv = document.createElement("DIV");
    var numberInput = document.createElement("INPUT");
    var initButton = new ActionButton("Generate Watches", ActionInit, mainDiv);
    var stopwatches = [];

    mainDiv.className = "maindiv";
    watchDiv.className = "watchdiv";
    numberInput.className = "numinput"
    numberInput.type = "number";
    numberInput.value = 1.0;
    mainDiv.appendChild(numberInput);
    mainDiv.appendChild(watchDiv);
    document.body.appendChild(mainDiv);

    function ActionInit() {
        //Delete all stopwatches and repopulate
        while(watchDiv.firstChild){
            watchDiv.removeChild(watchDiv.firstChild);
        }
        var n = numberInput.value;
        //console.log('gen button pressed' + n);
        for (var i=0; i<n; i++) {
            stopwatches[i] = new Stopwatch(i);
        }
    }

    //Stopwatch Class
    function Stopwatch(delay) {
        //Set up Stopwatch DOM
        var div = document.createElement("DIV");
        var playButton = new ActionButton("Start", ActionPlay, div);
        var pauseButton = new ActionButton("Pause", ActionPause, div);
        var resumeButton = new ActionButton("Resume", ActionResume, div)
        var resetButton = new ActionButton("Reset", ActionReset, div);
        var time = 0;
        var fade = 0.00;
        var isRunning = false;
        var doFadeIn = false;

        //set style and animation
        setTimeout(fadeIn, delay*250);
        div.className = "watch";
        div.style.opacity = "0.01";
        watchDiv.appendChild(div);
        run();

        function run() {
            //Initialize DOM elements
            var textBox =  document.createElement("H3");
            var canvas = document.createElement("CANVAS");
            var radius = 60;
            canvas.width = 200;
            canvas.height = 200;
            canvas.className = "drawingCanvas";
            textBox.className =  "timer";
            div.appendChild(textBox);
            div.appendChild(canvas);
            //Get canvas drawing context
            var context = canvas.getContext("2d");
            context.moveTo(0,0);
            context.strokeStyle = "black";
            context.fillStyle = "white";
            //stopwatch precision is hundredths of a second
            var timer = setInterval(tick, 10);
            function tick() {
                if (doFadeIn) {
                    fade += 0.01;
                    div.style.opacity = fade;
                }
                if (isRunning === true) {
                    time++;
                }
                textBox.innerText = format(time);
                //Draw on canvas
                context.strokeStyle = "black";
                context.beginPath();
                context.arc(100,100,radius,0, 2*Math.PI, true);
                context.closePath();
                context.fill();
                context.stroke();
                //centiseconds hand
                drawHand("silver",100+(Math.sin((time)*(Math.PI/50))*(radius * 0.5)), 100-(Math.cos((time)*(Math.PI/50))*(radius * 0.5)));
                //seconds hands
                drawHand("black", 100+(Math.sin((time/100)*(Math.PI/30))*(radius * 0.8)), 100-(Math.cos((time/100)*(Math.PI/30))*(radius * 0.8)));

                function drawHand(color, x, y) {
                    context.strokeStyle = color;
                    context.beginPath();
                    context.moveTo(100,100);
                    context.lineTo(x,y);
                    context.closePath();
                    context.stroke();
                }
            }
        }

        //Action button functions
        function ActionPlay() {
            //console.log('play button pressed');
            time = 0;
            isRunning = true;
        }

        function ActionPause() {
            //console.log('pause button pressed');
            isRunning = false;
        }

        function ActionResume() {
            //console.log('resume button pressed');
            isRunning = true;
        }

        function ActionReset() {
            //console.log('reset button pressed');
            isRunning = false;
            time = 0;
        }

        //Timer format functions
        function format(time) {
            var minutes = Math.floor(time / 6000)
            var seconds = Math.floor((time / 100)%60);
            var decimal = (time % 100);

            return (pad(minutes)+":"+pad(seconds) + "."+ pad(decimal));
        }

        function pad(num) {
            var val = num;
            if (num < 10) {
                val = "0" + num;
            }
            return val;
        }

        //Fadein animation
        function fadeIn() {
            doFadeIn = true;
            return;
        }

    }

    //ActionButton class
    function ActionButton(t, f, e) {
        var button = document.createElement("BUTTON");
        var text = document.createTextNode(t);
        button.appendChild(text);
        button.className = "actionButton";
        e.appendChild(button);
        button.addEventListener("click", function(){f();});
    }

}