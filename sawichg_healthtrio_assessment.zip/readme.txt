HealthTrio Assessment Summary
Gabriel Sawich
January 27, 2019

To run the app, launch the index.html file. In the prompt, enter the number of watches which you would like to generate,
then click the "Generate Watches" button (fractional numbers always round up). Each watch consists of 6 components:
Start, Pause, Resume and Reset buttons as well as both a digital and an analog watchface. The Start button will begin
from the zero mark. The pause button will halt the timer. The Resume button resumes the timer from the current mark, and
the Reset button stops the timer and resets it to zero. The analog watchface has two hands: a long one for seconds in
the minute and a shorter one for fractions of a second.

My solution to the presented problem is one which focuses on modular, reusable code with object-oriented principals. To
accomplish this, all the HTML DOM elements are generated via the Javascript code. This gives us precision control over
every element, which is demonstrated through the staggered fadein animations. As well as generating an arbitrary number
of watches, the addition of new buttons or hands on the watchface is only a single line of code away.

One hurdle I encountered during this process came from the inclusion of the HTML5 <canvas> element. I had encountered
some difficulty with incorrect aspect ratios, and it took a bit of digging into the documentation to understand
why. I discovered that <canvas> defaults to a 2:1 aspect ratio of 300x150 pixels, and that unlike other elements it has
two separate sets of "width" and "height" variables. One set of variables exists in the stylesheet, which controls the
size of the viewport, and another in the DOM which controls the size of the drawing surface. After understanding my
mistake, I set the proper conditions and the issue was resolved with the desired outcome.
